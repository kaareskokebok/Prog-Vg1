import os
import sys
import subprocess
import importlib

def install_package(package):
    try:
        importlib.import_module(package)
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Install missing packages
required_packages = ["requests", "tqdm"]
for package in required_packages:
    install_package(package)

import time
import requests
from tqdm import tqdm

def download_file(url, target_folder, target_name=None):
    if target_name is None:
        target_name = os.path.basename(url)

    os.makedirs(target_folder, exist_ok=True)
    target_path = os.path.join(target_folder, target_name)

    while True:
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()

            total_size = int(response.headers.get("Content-Length", 0))

            with open(target_path, "wb") as file, tqdm(
                desc=target_name,
                total=total_size,
                unit="iB",
                unit_scale=True,
                unit_divisor=1024,
            ) as progress_bar:
                for data in response.iter_content(chunk_size=1024):
                    size = file.write(data)
                    progress_bar.update(size)

            print(f"File downloaded successfully: {target_path}")
            break
        except requests.exceptions.RequestException as e:
            print(f"Error occurred while downloading: {e}")
            print("Retrying in 5 seconds...")
            time.sleep(5)

def download_files(download_tasks):
    for target_folder_parts, files in download_tasks.items():
        target_folder = os.path.join(*target_folder_parts)
        for file_info in files:
            url = file_info["url"]
            target_name = file_info.get("target_name")

            download_file(url, target_folder, target_name)

if __name__ == "__main__":
    download_tasks = {
        ("ComfyUI", "models", "clip_vision"): [
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/image_encoder/model.safetensors",
                "target_name": "CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/sdxl_models/image_encoder/model.safetensors",
                "target_name": "CLIP-ViT-bigG-14-laion2B-39B-b160k.safetensors"
            }
        ],
        ("ComfyUI", "models", "ipadapter"): [
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter_sd15.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter_sd15_light_v11.bin"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter-plus_sd15.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter-plus-face_sd15.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter-full-face_sd15.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/models/ip-adapter_sd15_vit-G.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/sdxl_models/ip-adapter_sdxl_vit-h.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/sdxl_models/ip-adapter-plus_sdxl_vit-h.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/sdxl_models/ip-adapter-plus-face_sdxl_vit-h.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter/resolve/main/sdxl_models/ip-adapter_sdxl.safetensors"
            }
        ],
        ("ComfyUI", "models", "loras"): [
            {
                "url": "https://huggingface.co/h94/IP-Adapter-FaceID/resolve/main/ip-adapter-faceid_sd15_lora.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter-FaceID/resolve/main/ip-adapter-faceid-plusv2_sd15_lora.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter-FaceID/resolve/main/ip-adapter-faceid_sdxl_lora.safetensors"
            },
            {
                "url": "https://huggingface.co/h94/IP-Adapter-FaceID/resolve/main/ip-adapter-faceid-plusv2_sdxl_lora.safetensors"
            }
        ]
    }

    download_files(download_tasks)