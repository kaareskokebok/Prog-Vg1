cd /workspace

git clone https://github.com/comfyanonymous/ComfyUI

cd /workspace/ComfyUI

python -m venv venv

source venv/bin/activate

pip install -r requirements.txt

pip uninstall torch torchvision torchaudio --yes

pip3 install torch==2.5.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124 --upgrade

pip install xformers==0.0.28.post2 --index-url https://download.pytorch.org/whl/cu124 --upgrade

pip install insightface

pip install onnxruntime-gpu

cd /workspace/ComfyUI/custom_nodes

git clone https://github.com/ltdrdata/ComfyUI-Manager

git clone https://github.com/cubiq/ComfyUI_IPAdapter_plus

cd /workspace/ComfyUI

cd /workspace

pip install requests

apt update

apt install psmisc

pip install triton

pip install https://files.pythonhosted.org/packages/2e/5c/2058713749655a6b1830ecb8d7db61637a396239610aeb11b59974d29b66/deepspeed-0.15.0-cp311-cp311-win_amd64.whl

python Download_Models.py

