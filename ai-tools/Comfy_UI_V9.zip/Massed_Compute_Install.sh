git clone https://github.com/comfyanonymous/ComfyUI

cd ComfyUI

python3 -m venv venv

source venv/bin/activate

pip install -r requirements.txt

pip uninstall torch torchvision torchaudio --yes

pip3 install torch==2.5.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124 --upgrade

pip install xformers==0.0.28.post2 --index-url https://download.pytorch.org/whl/cu124 --upgrade

pip install insightface

pip install onnxruntime-gpu

pip install triton

cd custom_nodes

git clone https://github.com/ltdrdata/ComfyUI-Manager

git clone https://github.com/cubiq/ComfyUI_IPAdapter_plus

cd ..
cd ..

pip install requests

sudo apt update

sudo apt install psmisc

sudo snap install ngrok

python3 Download_Models.py



